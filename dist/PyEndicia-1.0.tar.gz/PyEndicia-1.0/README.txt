=========
PyEndicia
=========

This project was written for a project that did not get off the ground so I decided to release the source.


